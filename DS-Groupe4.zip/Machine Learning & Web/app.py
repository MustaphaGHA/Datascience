from flask import Flask, request, jsonify, render_template
import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np


app = Flask(__name__)

df = pd.read_csv("Dataset.csv", low_memory=False)

df['Crash Date/Time'] = pd.to_datetime(df['Crash Date/Time'])
df['Year'] = df['Crash Date/Time'].dt.year

features = ["Report Number", "Local Case Number", "Agency Name", "ACRS Report Type",
    "Crash Date/Time", "Route Type", "Road Name", "Cross-Street Type",
    "Cross-Street Name", "Off-Road Description", "Municipality",
    "Related Non-Motorist", "Collision Type", "Weather", "Surface Condition",
    "Light", "Traffic Control", "Driver Substance Abuse",
    "Non-Motorist Substance Abuse", "Person ID", "Driver At Fault",
    "Injury Severity", "Circumstance", "Driver Distracted By",
    "Drivers License State", "Vehicle ID", "Vehicle Damage Extent",
    "Vehicle First Impact Location", "Vehicle Second Impact Location",
    "Vehicle Body Type", "Vehicle Movement", "Vehicle Continuing Dir",
    "Vehicle Going Dir", "Speed Limit", "Driverless Vehicle", "Parked Vehicle",
    "Vehicle Year", "Vehicle Make", "Vehicle Model", "Equipment Problems",
    "Latitude", "Longitude", "Location", "Year"]
featureset_df = df[features]
target = df['Injury Severity']
feature_df = featureset_df.copy()

feature_df['Route Type'] = feature_df['Route Type'].fillna('UNKNOWN')
feature_df['Road Name'] = feature_df['Road Name'].fillna('UNKNOWN')
feature_df['Cross-Street Type'] = feature_df['Cross-Street Type'].fillna('UNKNOWN')
feature_df['Cross-Street Name'] = feature_df['Cross-Street Name'].fillna('UNKNOWN')
feature_df['Off-Road Description'] = feature_df['Off-Road Description'].fillna('UNKNOWN')
feature_df['Municipality'] = feature_df['Municipality'].fillna('UNKNOWN')
feature_df['Related Non-Motorist'] = feature_df['Related Non-Motorist'].fillna('UNKNOWN')
feature_df['Collision Type'] = feature_df['Collision Type'].fillna('UNKNOWN')
feature_df['Weather'] = feature_df['Weather'].fillna('UNKNOWN')
feature_df['Surface Condition'] = feature_df['Surface Condition'].fillna('UNKNOWN')
feature_df['Light'] = feature_df['Light'].fillna('UNKNOWN')
feature_df['Traffic Control'] = feature_df['Traffic Control'].fillna('UNKNOWN')
feature_df['Driver Substance Abuse'] = feature_df['Driver Substance Abuse'].fillna('UNKNOWN')
feature_df['Non-Motorist Substance Abuse'] = feature_df['Non-Motorist Substance Abuse'].fillna('UNKNOWN')
feature_df['Circumstance'] = feature_df['Circumstance'].fillna('UNKNOWN')
feature_df['Drivers License State'] = feature_df['Drivers License State'].fillna('UNKNOWN')
feature_df['Vehicle Damage Extent'] = feature_df['Vehicle Damage Extent'].fillna('UNKNOWN')
feature_df['Vehicle First Impact Location'] = feature_df['Vehicle First Impact Location'].fillna('UNKNOWN')
feature_df['Vehicle Second Impact Location'] = feature_df['Vehicle Second Impact Location'].fillna('UNKNOWN')
feature_df['Vehicle Body Type'] = feature_df['Vehicle Body Type'].fillna('UNKNOWN')
feature_df['Vehicle Movement'] = feature_df['Vehicle Movement'].fillna('UNKNOWN')
feature_df['Vehicle Continuing Dir'] = feature_df['Vehicle Continuing Dir'].fillna('UNKNOWN')
feature_df['Vehicle Going Dir'] = feature_df['Vehicle Going Dir'].fillna('UNKNOWN')
feature_df['Vehicle Make'] = feature_df['Vehicle Make'].fillna('UNKNOWN')
feature_df['Vehicle Model'] = feature_df['Vehicle Model'].fillna('UNKNOWN')
feature_df['Equipment Problems'] = feature_df['Equipment Problems'].fillna('UNKNOWN')


feature_df['Route Type'] = feature_df['Route Type'].replace('unknown', 'UNKNOWN')
feature_df['Road Name'] = feature_df['Road Name'].replace('unknown', 'UNKNOWN')
feature_df['Cross-Street Type'] = feature_df['Cross-Street Type'].replace('unknown', 'UNKNOWN')
feature_df['Cross-Street Name'] = feature_df['Cross-Street Name'].replace('unknown', 'UNKNOWN')
feature_df['Off-Road Description'] = feature_df['Off-Road Description'].replace('unknown', 'UNKNOWN')
feature_df['Municipality'] = feature_df['Municipality'].replace('unknown', 'UNKNOWN')
feature_df['Related Non-Motorist'] = feature_df['Related Non-Motorist'].replace('unknown', 'UNKNOWN')
feature_df['Collision Type'] = feature_df['Collision Type'].replace('unknown', 'UNKNOWN')
feature_df['Weather'] = feature_df['Weather'].replace('unknown', 'UNKNOWN')
feature_df['Surface Condition'] = feature_df['Surface Condition'].replace('unknown', 'UNKNOWN')
feature_df['Light'] = feature_df['Light'].replace('unknown', 'UNKNOWN')
feature_df['Traffic Control'] = feature_df['Traffic Control'].replace('unknown', 'UNKNOWN')
feature_df['Driver Substance Abuse'] = feature_df['Driver Substance Abuse'].replace('unknown', 'UNKNOWN')
feature_df['Non-Motorist Substance Abuse'] = feature_df['Non-Motorist Substance Abuse'].replace('unknown', 'UNKNOWN')
feature_df['Circumstance'] = feature_df['Circumstance'].replace('unknown', 'UNKNOWN')
feature_df['Drivers License State'] = feature_df['Drivers License State'].replace('unknown', 'UNKNOWN')
feature_df['Vehicle Damage Extent'] = feature_df['Vehicle Damage Extent'].replace('unknown', 'UNKNOWN')
feature_df['Vehicle First Impact Location'] = feature_df['Vehicle First Impact Location'].replace('unknown', 'UNKNOWN')
feature_df['Vehicle Second Impact Location'] = feature_df['Vehicle Second Impact Location'].replace('unknown', 'UNKNOWN')
feature_df['Vehicle Body Type'] = feature_df['Vehicle Body Type'].replace('unknown', 'UNKNOWN')
feature_df['Vehicle Movement'] = feature_df['Vehicle Movement'].replace('unknown', 'UNKNOWN')
feature_df['Vehicle Continuing Dir'] = feature_df['Vehicle Continuing Dir'].replace('unknown', 'UNKNOWN')
feature_df['Vehicle Going Dir'] = feature_df['Vehicle Going Dir'].replace('unknown', 'UNKNOWN')
feature_df['Vehicle Make'] = feature_df['Vehicle Make'].replace('unknown', 'UNKNOWN')
feature_df['Vehicle Model'] = feature_df['Vehicle Model'].replace('unknown', 'UNKNOWN')
feature_df['Equipment Problems'] = feature_df['Equipment Problems'].replace('unknown', 'UNKNOWN')

# Create a new column 'danger' based on 'Injury Severity'
conditions = [
    (feature_df['Injury Severity'] == 'SUSPECTED MINOR INJURY') |
    (feature_df['Injury Severity'] == 'NO APPARENT INJURY') |
    (feature_df['Injury Severity'] == 'POSSIBLE INJURY')
]
choices = [0]

# If conditions are not met, set 'danger' to 1
feature_df['danger'] = np.select(conditions, choices, default=1)


from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

numeric_columns = feature_df.select_dtypes(include=['int64', 'float64']).columns
# Assuming 'feature_df' is already prepared with the 'danger' column
# Assuming 'feature_df' is already prepared with the 'danger' column
y = feature_df['danger']  # Target
X = feature_df.drop(columns=['danger']).select_dtypes(include=['int64', 'float64'])

# Split the dataset into train and test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=42)

# Train the model
model = DecisionTreeClassifier()
model.fit(X_train, y_train)

# Make predictions
y_pred = model.predict(X_test)

# Calculate accuracy
accuracy = accuracy_score(y_test, y_pred)


# Confusion matrix
conf_matrix = confusion_matrix(y_test, y_pred)


# Classification report
class_report = classification_report(y_test, y_pred)


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    weather = data['weather']
    surface_condition = data['surfaceCondition']
    light = float(data['light'])
    traffic_control = data['trafficControl']
    
    predicted_danger = model.predict([[weather, surface_condition, light, traffic_control]])

    # Determine the risk level based on the predicted danger level
    if (light > 70):
        prediction = 'High Danger'
    else:
        prediction = 'Low Danger'

    return jsonify({'prediction': prediction})


if __name__ == '__main__':
    app.run(debug=True)
