import requests
from bs4 import BeautifulSoup
import csv

def scrape_table_data(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')

    table_data = []
    parent= soup.find('table', {'class': "Table Table--text Table--fixed Table--stripedOdd Table--spacing1 table-inline"})
    print(parent)


    if parent:
        rows = parent.find_all('tr')
        for row in rows:
            columns = row.find_all(['th', 'td'])
            row_data = [column.get_text(strip=True) for column in columns]
            table_data.append(row_data)

    return table_data

def write_to_csv(data, filename):
    with open(filename, 'w', newline='', encoding='utf-8') as csv_file:
        csv_writer = csv.writer(csv_file)
        csv_writer.writerows(data)


url = 'https://www.bankrate.com/insurance/car/car-crash-statistics/?fbclid=IwAR1_DNgJRuenuUFDO5Sf65FNKpXsqcM3sn_sW5U4qj9IGjY6cATx2IiGTEI#car-crashes-over-time'  # Replace with the actual URL of the webpage
scrape= scrape_table_data(url);
table_data = scrape;

if table_data:
    write_to_csv(table_data, 'bankrate_com.csv')
    print('Table data exported to booksData.csv')
else:
    print('Error: Table not found on the webpage.')
